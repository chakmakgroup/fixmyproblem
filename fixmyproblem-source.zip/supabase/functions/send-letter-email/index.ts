import 'jsr:@supabase/functions-js/edge-runtime.d.ts';

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface SendEmailRequest {
  to: string;
  customerName: string;
  letterText: string;
  pdfBase64: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    console.log('=== EDGE FUNCTION: send-letter-email invoked ===');

    if (!RESEND_API_KEY) {
      console.error('RESEND_API_KEY is not configured');
      return new Response(
        JSON.stringify({ error: 'Email service not configured' }),
        {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const { to, customerName, letterText, pdfBase64 }: SendEmailRequest = await req.json();

    console.log('Request payload received:');
    console.log('  → Recipient Email (to):', to);
    console.log('  → Customer Name:', customerName);
    console.log('  → Letter Length:', letterText?.length, 'characters');
    console.log('  → PDF Base64 Length:', pdfBase64?.length, 'characters');

    if (!to || !customerName || !letterText || !pdfBase64) {
      console.error('CRITICAL: Missing required fields in request!', {
        hasTo: !!to,
        hasCustomerName: !!customerName,
        hasLetterText: !!letterText,
        hasPdfBase64: !!pdfBase64,
      });
      return new Response(
        JSON.stringify({ error: 'Missing required fields: to, customerName, letterText, pdfBase64' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const emailBody = `
      <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #4F7DF3; font-size: 24px; margin-bottom: 10px;">Your Letter is Ready!</h1>
          <p style="color: #666; font-size: 14px;">Thank you for using FixMyProblem</p>
        </div>

        <div style="background: #f8fafc; border-left: 4px solid #4F7DF3; padding: 20px; margin-bottom: 30px;">
          <p style="margin: 0; color: #333;">Hi ${customerName},</p>
          <p style="margin-top: 15px; color: #666;">
            Your professionally written complaint letter is attached to this email as a PDF.
            You can download it, print it, or forward it directly to the relevant party.
          </p>
        </div>

        <div style="background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-bottom: 30px;">
          <h2 style="color: #333; font-size: 16px; margin-top: 0; margin-bottom: 15px;">📄 Letter Preview</h2>
          <div style="font-family: Georgia, serif; white-space: pre-wrap; color: #333; font-size: 14px; line-height: 1.7; max-height: 400px; overflow: auto; border: 1px solid #e5e7eb; padding: 15px; border-radius: 4px;">
${letterText}
          </div>
        </div>

        <div style="background: #14B8A6; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 30px;">
          <h3 style="margin: 0 0 10px 0; font-size: 18px;">✓ What's Included</h3>
          <ul style="list-style: none; padding: 0; margin: 10px 0 0 0; text-align: left; display: inline-block;">
            <li style="margin-bottom: 8px;">✓ Professional UK formatted letter</li>
            <li style="margin-bottom: 8px;">✓ Ready to send or print</li>
            <li style="margin-bottom: 8px;">✓ PDF attachment included</li>
            <li>✓ Fully customizable for your needs</li>
          </ul>
        </div>

        <div style="text-align: center; padding-top: 20px; border-top: 1px solid #e5e7eb;">
          <p style="color: #666; font-size: 13px; margin-bottom: 10px;">
            Need another letter? Visit us at <a href="https://fixmyproblem.uk" style="color: #4F7DF3;">FixMyProblem.uk</a>
          </p>
          <p style="color: #999; font-size: 12px; margin: 0;">
            This email was sent because you purchased a letter from FixMyProblem.
          </p>
        </div>
      </div>
    `;

    const fromEmail = 'FixMyProblem <noreply@fixmyproblem.co.uk>';

    console.log('=== RESEND API CALL ===');
    console.log('From:', fromEmail);
    console.log('To:', to);
    console.log('Subject: Your FixMyProblem Letter is Ready 📄');
    console.log('Has HTML body:', !!emailBody);
    console.log('Has PDF attachment:', !!pdfBase64);

    const resendPayload = {
      from: fromEmail,
      to: [to],
      subject: 'Your FixMyProblem Letter is Ready 📄',
      html: emailBody,
      attachments: [
        {
          filename: 'fixmyproblem-letter.pdf',
          content: pdfBase64,
        },
      ],
    };

    console.log('Payload size:', JSON.stringify(resendPayload).length, 'bytes');

    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(resendPayload),
    });

    console.log('Resend API Response Status:', resendResponse.status);
    console.log('Resend API Response OK:', resendResponse.ok);

    const result = await resendResponse.json();
    console.log('Resend API Response Body:', JSON.stringify(result, null, 2));

    if (!resendResponse.ok) {
      console.error('=== RESEND API ERROR ===');
      console.error('Status:', resendResponse.status);
      console.error('Response:', result);
      return new Response(
        JSON.stringify({ error: 'Failed to send email', details: result }),
        {
          status: resendResponse.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    console.log('=== EMAIL QUEUED SUCCESSFULLY ===');
    console.log('Email ID:', result.id);
    console.log('Status:', result.status || 'queued');

    return new Response(
      JSON.stringify({ success: true, emailId: result.id }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error sending email:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
