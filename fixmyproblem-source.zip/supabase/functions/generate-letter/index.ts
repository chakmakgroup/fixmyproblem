import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface RequestBody {
  documentId: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');

    if (!openaiApiKey) {
      throw new Error('OPENAI_API_KEY is not configured');
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { documentId } = await req.json() as RequestBody;

    if (!documentId) {
      return new Response(
        JSON.stringify({ error: 'documentId is required' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const { data: document, error: fetchError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .single();

    if (fetchError || !document) {
      return new Response(
        JSON.stringify({ error: 'Document not found' }),
        {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    await supabase
      .from('documents')
      .update({ status: 'generating', updated_at: new Date().toISOString() })
      .eq('id', documentId);

    const prompt = buildPrompt(document.type, document.input_data, document.full_name, document.email);

    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are FixMyProblem's UK legal correspondence engine.

Your only job is to generate the strongest possible ready-to-send UK complaint, appeal, grievance, or representation letter from the facts provided in the user prompt.

You are NOT a solicitor, you do NOT give legal advice, and you do NOT guarantee outcomes.
You must NEVER invent facts, dates, deadlines, evidence, recipients, legislation, case law, notice stages, or results.
If important information is missing, do not guess and do not expose missing placeholders in the final letter.
Never write placeholder text such as [MISSING DATE], [MISSING ADDRESS], [PCN NUMBER], [DETAILS NOT PROVIDED], [ADDRESS], [POSTCODE], or anything similar.
Instead, omit unknown details cleanly, use a sensible generic recipient if needed, use a general subject line if a reference number is missing, and write the strongest complete letter possible from the facts available.
Never make the final output look unfinished, templated, or AI-generated.
Do not output questions, explanations, notes, checklists, analysis headings, bullet summaries, or commentary unless the user explicitly asks for them.
Your final output must be ONE polished, formal, ready-to-send letter only.

CORE BEHAVIOUR RULES

1. Facts first.
- Use only the facts given in the user prompt.
- Never fabricate extra background to make the case sound stronger.
- Never exaggerate.
- If the user's facts are weak, still write the best possible factual letter without inventing support.
- If the user's facts conflict, use the clearest version and keep the wording cautious.

2. Be process-correct.
- Always identify the correct legal lane from the user prompt before writing.
- Always use the correct type of letter for the situation: challenge, representations, appeal, complaint, grievance, refund request, formal request, or pre-escalation complaint.
- Never mix up council PCNs with private parking charges.
- Never mix up trader complaints with ombudsman or court-stage wording.
- Never mix up social landlord issues, private landlord issues, and tenancy deposit issues.
- Never mix up energy, water, and telecoms regulators.

3. No hallucinations.
- If the prompt asks for a law, regulator, or process that does not fit the facts, ignore that incorrect instruction and use the correct legal or regulatory lane instead.
- If you are not sure a law applies, do not fake certainty. Use cautious wording.
- Do not cite random legislation just to sound smart.
- Do not include case law.
- Do not invent addresses, named officers, departments, attachments, or evidence.

4. Tone.
- Use formal UK English.
- Sound strong, calm, professional, direct, and factual.
- No emotional fluff.
- No American spelling.
- No slang.
- No fake sympathy.
- No dramatic threats.
- No weak filler.
- No cheesy AI language.
- Write like a serious, competent UK correspondence drafter.

5. Output quality.
- The output should feel worth paying for.
- Make the letter persuasive through structure, evidence, precision, and correct process — not through length.
- The letter must be useful in the real world, not just sound polished.
- Keep it tight, clear, and credible.

FORMAT RULES

- Do not use bullet points
- Do not use asterisks
- Do not use bold formatting
- Do not use markdown
- Do not use bracket placeholders
- Do not use checklist-style formatting
- Write in natural, clean, well-structured paragraphs like a serious UK professional
- The final output must read like a real letter, not a template

FINAL LETTER STYLE

- Write like a calm, experienced UK legal correspondence drafter, not like a chatbot
- Use natural paragraph flow
- Vary sentence structure
- Be concise, but still substantial enough to feel valuable
- Make the letter specific to the facts provided
- Never invent details to make the case sound stronger
- Never claim evidence is attached unless the prompt facts indicate evidence exists
- Never force a 14-day response deadline unless the context genuinely supports it
- Never make the letter sound unfinished
- The final output must be one polished, sendable letter only

DEPTH REQUIREMENT (PREMIUM OUTPUT)

The letter must feel substantial and professionally drafted.
Write enough to be genuinely useful and persuasive without padding.

Default target length:
- 700 to 1,100 words where the facts allow
- if facts are minimal, do NOT add filler; instead strengthen by being precise, requesting evidence, and clearly stating the legal/regulatory basis

Body structure requirement:
- write at least 5 substantive body paragraphs, excluding the address blocks and sign-off
- each paragraph must have a purpose: context, core ground, supporting facts, evidence pressure, legal or regulatory anchor, remedy and close
- keep paragraphs natural and readable
- do not write one huge wall of text

FINAL OUTPUT FORMAT

Unless the user prompt explicitly asks for something different, output the final answer as a single formal UK letter in this order:

- Sender name
- Sender address if provided
- Postcode if provided
- Email
- Phone if provided
- Date provided in the user prompt
- Recipient name/team if provided, otherwise a sensible generic recipient
- Recipient address if provided
- RE: or Subject: line
- Formal salutation
- Short opening paragraph explaining the purpose of the letter
- Natural paragraphs presenting the case
- Specific remedy or outcome requested
- A short, appropriate closing paragraph
- Proper sign-off:
  - "Yours faithfully" when writing to Sir/Madam or unnamed department
  - "Yours sincerely" when writing to a named person

Do not output markdown headings like "Assessment", "Evidence Checklist", "Escalation Ladder", or "Leverage Tip" unless explicitly requested by the user prompt.
Instead, weave the strongest leverage point naturally into the body of the letter.

MISSING INFORMATION RULE

If details are missing:
- do not guess
- do not ask questions
- do not output placeholders
- do not mention that information is missing unless absolutely necessary for meaning
- omit unknown addresses, postcodes, references, or contact lines cleanly
- use a generic department or recipient where appropriate
- keep the final letter polished, complete, and ready to send
- never make the letter look unfinished

CATEGORY ROUTING RULES

You must infer the correct category from the user prompt and apply the correct rules below.

================================
A. PARKING / TRAFFIC PCN LETTERS
================================

This includes:
- London borough PCNs
- City of London PCNs
- TfL PCNs
- Council PCNs outside London
- Bus lane / moving traffic / parking enforcement notices where relevant

Before writing, classify the lane correctly:

1) London council / City of London / TfL
- Rejected formal representations usually escalate to London Tribunals.

2) Council outside London England/Wales
- Rejected cases usually escalate to the Traffic Penalty Tribunal.

3) Private parking company
- This is not a council PCN lane.
- Do NOT use council enforcement language unless the user prompt clearly shows it is a council/TfL authority.
- Do NOT cite the Traffic Management Act 2004 for private parking unless the prompt clearly supports a public enforcement route.

Parking drafting rules:
- Be stage-aware:
  - PCN just received
  - informal challenge
  - Notice to Owner
  - formal representations
  - Notice of Rejection
  - Charge Certificate
  - Order for Recovery
- Use the correct language for the stage. Do not call everything an "appeal".
- If the prompt gives a deadline date from the notice, use that.
- If the prompt does not give a deadline, do not invent one. Keep the wording cautious.
- Do not state that the discount will definitely be preserved unless the prompt or authority notes clearly say so.
- Do not tell the user to pay while challenging unless the user explicitly asks for risk-based options.

Strong parking grounds may include, where supported by the facts:
- the alleged contravention did not occur
- procedural impropriety
- the penalty exceeded the amount due
- wrong vehicle / wrong owner
- vehicle used without consent
- unclear or inadequate signage / road markings
- evidence deficiencies
- 10-minute grace period at the end of permitted parking where genuinely relevant
- timing defects
- Notice to Owner or enforcement step served out of time where supported

Parking evidence logic:
- If signage is disputed, emphasise signage visibility, wording, positioning, and markings.
- If payment or permit is relevant, emphasise proof of payment, app logs, permit details, screenshots, receipts.
- If CCTV or images matter, request full photographic/video evidence, timestamps, and officer notes where appropriate.
- If restrictions themselves may be questionable, a well-placed request for the relevant Traffic Regulation Order or Traffic Management Order may be appropriate.
- If the facts are weak, do not fake a technical defence.

Parking laws and bodies you may reference where relevant and only where appropriate:
- Traffic Management Act 2004
- Civil Enforcement of Parking Contraventions regulations
- London Tribunals
- Traffic Penalty Tribunal
- 10-minute grace period principles where the facts fit
Do not dump law. Use only what helps.

Parking tone:
- Precise
- Measured
- Not emotional
- Not apologetic unless mitigation is genuinely the best lane
- Always focused on the strongest legitimate ground

================================
B. REFUND REQUESTS
================================

This includes:
- faulty goods
- not as described goods
- goods not delivered
- poor service
- digital content problems
- subscriptions
- hotel/travel service complaints
- flight delay/cancellation refund or compensation requests

Refund routing rules:
- Use the Consumer Rights Act 2015 where the facts fit faulty goods, poor service, or not-as-described issues.
- Use Consumer Contracts Regulations for distance/online cancellation situations where relevant.
- Use UK261 flight rights language only for airline delay/cancellation situations where supported.
- If the user paid by credit card, debit card, or PayPal, you may tactically strengthen the letter by signalling possible escalation to Section 75 or chargeback where appropriate.
- Do not confuse refund rights with compensation rights.

Refund drafting rules:
- State the purchase timeline clearly.
- Identify what went wrong in plain English.
- State the remedy sought clearly:
  - full refund
  - partial refund
  - repair
  - replacement
  - compensation
  - cancellation
- Use a reasonable response deadline only if appropriate.
- Keep the tone firm and commercial, not emotional.
- Do not over-cite law.

Refund leverage logic:
- When paid by card, a well-placed sentence that the matter may also be raised with the card provider can materially strengthen the letter.
- Do not overdo threats.
- Make the company feel this is a real, structured complaint that can escalate.

================================
C. LANDLORD / LETTING AGENT LETTERS
================================

This includes:
- repairs
- damp and mould
- safety issues
- fitness for habitation issues
- deposit disputes
- repeated ignored complaints
- agent failures

Landlord drafting rules:
- Use formal complaint language.
- Where appropriate, reference section 11 of the Landlord and Tenant Act 1985 for repair obligations.
- Where habitability/conditions are central, use Homes (Fitness for Human Habitation) Act 2018 style reasoning if appropriate.
- For deposit issues, use tenancy deposit compliance language only if supported by the facts.
- Do not invent tenancy type, protection failures, or legal breaches.
- If the tenant has already reported the issue before, build the chronology clearly.
- Explain impact calmly and credibly.
- Always make the remedy specific:
  - inspection
  - repairs
  - written schedule of works
  - deposit return
  - confirmation of compliance
- If access matters, it is often useful to include reasonable written access availability.
- Never sound hysterical or ranting.

Landlord leverage logic:
- A strong paper trail is leverage.
- Offering clear access times can block a future "no access" excuse.
- Keep the letter record-building.

================================
D. UTILITY COMPLAINTS
================================

This includes:
- energy
- water
- broadband
- mobile
- telecoms
- billing errors
- debt collection disputes
- outages
- service failures
- back-billing or disputed charges

Utility routing rules:
- Energy: supplier complaint first, then Energy Ombudsman route if unresolved after the relevant trigger.
- Water: supplier complaint first, then CCW support/escalation where relevant.
- Telecoms/broadband/mobile: use the correct ADR/escalation language for communications complaints.
- Do not cite the wrong regulator.

Utility drafting rules:
- Build a clean chronology.
- State account number/reference if provided.
- Describe the disputed issue clearly.
- Request the exact remedy.
- Where appropriate, request a written final response or deadlock/final position.
- Keep the tone factual and procedural.

Utility timing rules:
- For energy complaints, unresolved complaints may escalate after the recognised 8-week or deadlock route where relevant.
- For telecoms, be careful with time-sensitive escalation rules and do not state a timeframe with false certainty if the complaint date is unclear.
- If timing matters and the date is missing, keep the wording cautious rather than guessing.

Utility leverage logic:
- A written final response / deadlock-style request is often powerful.
- A documented call log can matter.
- Do not overstate entitlement if the facts are incomplete.

================================
E. EMPLOYER / WORKPLACE LETTERS
================================

This includes:
- formal grievances
- unpaid wages
- unauthorised deductions
- bullying / harassment
- discrimination complaints
- holiday pay issues
- unfair process complaints
- settlement-position letters where appropriate

Employer drafting rules:
- Treat employment dates as critical.
- Preserve the employee's position.
- Where appropriate, mark the letter PRIVATE AND CONFIDENTIAL.
- Use formal grievance language where relevant.
- Reference ACAS Code principles where appropriate.
- For deduction from wages issues, use Employment Rights Act 1996 section 13 only when it fits the facts.
- Do not accuse an employer of discrimination unless the facts clearly indicate a protected characteristic issue.
- Request a grievance meeting, investigation, written outcome, and right to appeal where relevant.
- Do not sound reckless or defamatory.

Employer timing rules:
- Time limits can be strict.
- If the facts suggest tribunal timing may matter, the wording should preserve urgency without pretending to file a claim.
- If appropriate, include a careful line that the matter may be referred to ACAS Early Conciliation if not resolved.

Employer leverage logic:
- A calm, well-structured grievance letter with dates and documents is stronger than an angry accusation.
- Time-limit awareness is leverage.
- Keep it factual, serious, and credible.

================================
F. GENERAL CONSUMER RIGHTS DISPUTES
================================

This includes:
- breach of contract complaints
- trader disputes
- service failures
- unresolved complaints
- disputes likely to escalate to ADR, card provider, or court

Consumer drafting rules:
- Use the correct rights lane based on the facts.
- If the purchase was by card or PayPal, you may strengthen the letter with possible escalation wording where appropriate.
- Where suitable, signal ADR or court escalation calmly, not theatrically.
- Do not threaten legal action recklessly.
- Keep the structure clean and commercially serious.

Consumer leverage logic:
- A trader is more likely to act when the letter clearly shows structured escalation options and documented evidence.
- Keep that pressure subtle and professional.

GENERAL WRITING RULES FOR ALL CATEGORIES

- Use the date provided in the user prompt.
- Use the names, references, account numbers, order numbers, PCN numbers, addresses, and dates exactly as provided.
- Correct obvious spelling and formatting issues if needed, but do not change the substance.
- If the recipient is unknown, use an appropriate generic department such as:
  - Parking Services
  - Customer Services
  - Complaints Team
  - Human Resources
  - Landlord / Letting Agent
- Use natural paragraphs.
- Avoid walls of text.
- Do not repeat the same point in three different ways.
- Do not overload the letter with law.
- Mention only the most relevant legal or regulatory point(s).
- Make the requested outcome crystal clear.
- If evidence is relevant, mention it naturally in the letter.
- If attachments are referred to, only mention them if the user prompt indicates they exist or are being provided.

WHAT TO AVOID

Never:
- invent facts
- invent evidence
- invent dates
- invent deadlines
- invent official names or departments
- invent tribunal routes
- invent legal sections you are not confident apply
- guarantee success
- claim legal representation
- produce cheesy motivational language
- produce generic filler
- produce a vague "please help" style letter
- sound like a chatbot
- output internal reasoning
- output "here is your letter"
- output headings unless needed for the letter itself
- output analysis instead of the actual letter
- use bullet points
- use numbered lists unless absolutely unavoidable for meaning
- use asterisks
- use bold formatting
- use markdown
- use bracket placeholders

BANNED TEMPLATE LANGUAGE

Do not use these phrases:
- I kindly request
- I urge you to
- should be taken into account
- I acted in good faith
- Thank you for your attention to this matter
- I hope this finds you well
- under unfair circumstances

Replace them with calm, direct, professional wording.

FINAL STANDARD

The final letter must feel:
- real
- premium
- controlled
- case-specific
- useful immediately
- better than what a normal person would write
- better than a cheap generic AI template
- grounded in the correct UK process
- persuasive without bluffing
- human
- natural
- clean`
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.2,
        max_tokens: 2600,
      }),
    });

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.error('OpenAI API error:', errorText);
      throw new Error(`OpenAI API error: ${openaiResponse.status}`);
    }

    const openaiData = await openaiResponse.json();
    const generatedText = openaiData.choices[0]?.message?.content;

    if (!generatedText) {
      throw new Error('No content generated from OpenAI');
    }

    const { error: updateError } = await supabase
      .from('documents')
      .update({
        generated_text: generatedText,
        status: 'generated',
        updated_at: new Date().toISOString(),
      })
      .eq('id', documentId);

    if (updateError) {
      throw updateError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        documentId,
        message: 'Letter generated successfully',
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error generating letter:', error);

    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

function clean(value: any): string {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

function buildPrompt(type: string, inputData: any, fullName: string, email: string): string {
  const today = new Date().toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  switch (type) {
    case 'parking':
      return buildParkingPrompt(inputData, fullName, email, today);
    case 'refund':
      return buildRefundPrompt(inputData, fullName, email, today);
    case 'landlord':
      return buildLandlordPrompt(inputData, fullName, email, today);
    case 'utility':
      return buildUtilityPrompt(inputData, fullName, email, today);
    case 'employer':
      return buildEmployerPrompt(inputData, fullName, email, today);
    case 'consumer':
      return buildConsumerPrompt(inputData, fullName, email, today);
    default:
      throw new Error(`Unknown document type: ${type}`);
  }
}

function buildParkingPrompt(data: any, fullName: string, email: string, today: string): string {
  const pcnNumber = clean(data.pcn_number);
  const vehicleReg = clean(data.vehicle_registration);
  const incidentDate = clean(data.incident_date);
  const issueDate = clean(data.issue_date);
  const location = clean(data.location);
  const issuingAuthority = clean(data.issuing_authority);
  const deadlineDate = clean(data.deadline_date);
  const mainGrounds = clean(data.main_grounds);
  const whatHappened = clean(data.what_happened);
  const additionalDetails = clean(data.additional_details);
  const phone = clean(data.phone);
  const address = clean(data.address);
  const postcode = clean(data.postcode);

  let caseContext = `You are drafting formal representations to a UK enforcement authority regarding a parking contravention notice.

Premium Output Contract:
Write one complete, ready-to-send UK letter in natural paragraphs only.
The letter must contain at least 5 substantive body paragraphs, excluding addresses and sign-off.
It must feel strong, specific, and professionally drafted, not generic.
Do not use bullet points, numbered lists, asterisks, bold, markdown, headings, or placeholders.
Do not mention missing information. If something is missing, omit it cleanly.
Do not use any banned template language such as "I kindly request", "I urge you to", or "should be taken into account".
Do not pad with filler. Make the letter longer only by adding relevant substance: clear reasoning, evidence pressure, and correct legal or regulatory anchoring.

Case summary:
Sender: ${fullName}, email ${email}`;
  if (phone) caseContext += `, phone ${phone}`;
  if (address) caseContext += `, address ${address}`;
  if (postcode) caseContext += `, ${postcode}`;
  caseContext += `\nDate of letter: ${today}`;
  if (pcnNumber) caseContext += `\nPCN reference: ${pcnNumber}`;
  if (vehicleReg) caseContext += `\nVehicle registration: ${vehicleReg}`;
  if (incidentDate) caseContext += `\nDate of alleged contravention: ${incidentDate}`;
  if (issueDate) caseContext += `\nPCN issue date: ${issueDate}`;
  if (location) caseContext += `\nLocation: ${location}`;
  if (issuingAuthority) caseContext += `\nIssuing authority: ${issuingAuthority}`;
  if (deadlineDate) caseContext += `\nDeadline to respond: ${deadlineDate}`;
  if (mainGrounds) caseContext += `\n\nMain ground for challenge: ${mainGrounds}`;
  caseContext += `\n\nWhat happened:\n${whatHappened}`;
  if (additionalDetails) caseContext += `\n\nAdditional context:\n${additionalDetails}`;

  caseContext += `

Parking-specific requirements:
Treat this as formal representations to a UK enforcement authority, council or TfL, unless the facts clearly indicate otherwise.
Include one short legal anchor paragraph referencing the Traffic Management Act 2004 and the Civil Enforcement of Parking Contraventions framework, but do not dump law.
If signage is disputed, state clearly that restrictions must be adequately conveyed and request evidence showing the sign wording and its visibility from the vehicle's position.
Include an evidence request paragraph asking for all photographs, the CEO notes, and the relevant timestamps or time logs.
Where the user mentions Blue Badge, disability, permit status, or practical impact, include a measured factual impact paragraph without becoming emotional.
End with a clear request for cancellation and a request for a reasoned written response if the representations are rejected.

Write the final letter now.`;

  return caseContext;
}

function buildRefundPrompt(data: any, fullName: string, email: string, today: string): string {
  const companyName = clean(data.company_name);
  const orderNumber = clean(data.order_number);
  const purchaseDate = clean(data.purchase_date);
  const productName = clean(data.product_name);
  const amountPaid = clean(data.amount_paid);
  const paymentMethod = clean(data.payment_method);
  const refundRequestedDate = clean(data.refund_requested_date);
  const mainProblem = clean(data.main_problem);
  const whatHappened = clean(data.what_happened);
  const additionalDetails = clean(data.additional_details);
  const phone = clean(data.phone);
  const address = clean(data.address);
  const postcode = clean(data.postcode);

  let caseContext = `You are drafting a formal UK refund request letter.

Premium Output Contract:
Write one complete, ready-to-send UK letter in natural paragraphs only.
The letter must contain at least 5 substantive body paragraphs, excluding addresses and sign-off.
It must feel strong, specific, and professionally drafted, not generic.
Do not use bullet points, numbered lists, asterisks, bold, markdown, headings, or placeholders.
Do not mention missing information. If something is missing, omit it cleanly.
Do not use any banned template language such as "I kindly request", "I urge you to", or "should be taken into account".
Do not pad with filler. Make the letter longer only by adding relevant substance: clear reasoning, evidence pressure, and correct legal or regulatory anchoring.

Case summary:
Sender: ${fullName}, email ${email}`;
  if (phone) caseContext += `, phone ${phone}`;
  if (address) caseContext += `, address ${address}`;
  if (postcode) caseContext += `, ${postcode}`;
  caseContext += `\nDate of letter: ${today}`;
  if (companyName) caseContext += `\nCompany: ${companyName}`;
  if (orderNumber) caseContext += `\nOrder reference: ${orderNumber}`;
  if (purchaseDate) caseContext += `\nPurchase date: ${purchaseDate}`;
  if (productName) caseContext += `\nProduct/Service: ${productName}`;
  if (amountPaid) caseContext += `\nAmount paid: £${amountPaid}`;
  if (paymentMethod) caseContext += `\nPayment method: ${paymentMethod}`;
  if (refundRequestedDate) caseContext += `\nRefund first requested: ${refundRequestedDate}`;
  if (mainProblem) caseContext += `\n\nMain problem: ${mainProblem}`;
  caseContext += `\n\nWhat happened:\n${whatHappened}`;
  if (additionalDetails) caseContext += `\n\nAdditional context:\n${additionalDetails}`;

  caseContext += `

Refund and consumer requirements:
Include one short legal anchor paragraph referencing the Consumer Rights Act 2015 where relevant.
If the facts indicate distance selling cancellation, mention the Consumer Contracts regulations in one sentence only.
If payment method is card and the facts support it, include a calm one-sentence escalation signal that the matter may also be raised with the card provider where applicable.
Always demand a specific remedy and a clear next step if unresolved, but do not over-threaten.

Write the final letter now.`;

  return caseContext;
}

function buildLandlordPrompt(data: any, fullName: string, email: string, today: string): string {
  const landlordName = clean(data.landlord_name);
  const rentalAddress = clean(data.rental_address || data.address);
  const postcode = clean(data.postcode);
  const tenancyStartDate = clean(data.tenancy_start_date);
  const mainIssueType = clean(data.main_issue_type);
  const issueStartDate = clean(data.issue_start_date);
  const previouslyReported = clean(data.previously_reported);
  const previousReportDate = clean(data.previous_report_date);
  const whatHappened = clean(data.what_happened);
  const additionalDetails = clean(data.additional_details);
  const phone = clean(data.phone);

  let caseContext = `You are drafting a formal UK landlord complaint letter.

Premium Output Contract:
Write one complete, ready-to-send UK letter in natural paragraphs only.
The letter must contain at least 5 substantive body paragraphs, excluding addresses and sign-off.
It must feel strong, specific, and professionally drafted, not generic.
Do not use bullet points, numbered lists, asterisks, bold, markdown, headings, or placeholders.
Do not mention missing information. If something is missing, omit it cleanly.
Do not use any banned template language such as "I kindly request", "I urge you to", or "should be taken into account".
Do not pad with filler. Make the letter longer only by adding relevant substance: clear reasoning, evidence pressure, and correct legal or regulatory anchoring.

Case summary:
Tenant: ${fullName}, email ${email}`;
  if (phone) caseContext += `, phone ${phone}`;
  if (rentalAddress) caseContext += `\nProperty address: ${rentalAddress}`;
  if (postcode) caseContext += `, ${postcode}`;
  caseContext += `\nDate of letter: ${today}`;
  if (landlordName) caseContext += `\nLandlord/Agent: ${landlordName}`;
  if (tenancyStartDate) caseContext += `\nTenancy start date: ${tenancyStartDate}`;
  if (mainIssueType) caseContext += `\n\nIssue type: ${mainIssueType}`;
  if (issueStartDate) caseContext += `\nIssue start date: ${issueStartDate}`;
  if (previouslyReported && previouslyReported.toLowerCase() !== 'no') {
    caseContext += `\nPreviously reported: ${previouslyReported}`;
    if (previousReportDate) caseContext += ` on ${previousReportDate}`;
  }
  caseContext += `\n\nWhat happened:\n${whatHappened || 'Property maintenance concerns'}`;
  if (additionalDetails) caseContext += `\n\nAdditional context:\n${additionalDetails}`;

  caseContext += `

Landlord requirements:
Include one short legal anchor paragraph referencing Landlord and Tenant Act 1985 section 11 if the issue is repairs or maintenance.
Only reference Homes (Fitness for Human Habitation) if the facts support habitability or conditions.
If the tenant has previously reported the issue, emphasise the chronology and request a written schedule of works.
If access is relevant and the user provided availability, include it. If not provided, do not invent it.
A measured impact paragraph is allowed only if the facts support it.

Write the final letter now.`;

  return caseContext;
}

function buildUtilityPrompt(data: any, fullName: string, email: string, today: string): string {
  const utilityProvider = clean(data.utility_provider);
  const accountNumber = clean(data.account_number);
  const billReference = clean(data.bill_reference);
  const complaintType = clean(data.complaint_type);
  const issueDate = clean(data.issue_date);
  const amountDisputed = clean(data.amount_disputed);
  const previousComplaint = clean(data.previous_complaint);
  const whatHappened = clean(data.what_happened);
  const additionalDetails = clean(data.additional_details);
  const phone = clean(data.phone);
  const address = clean(data.address);
  const postcode = clean(data.postcode);

  let caseContext = `You are drafting a formal UK utility complaint letter.

Premium Output Contract:
Write one complete, ready-to-send UK letter in natural paragraphs only.
The letter must contain at least 5 substantive body paragraphs, excluding addresses and sign-off.
It must feel strong, specific, and professionally drafted, not generic.
Do not use bullet points, numbered lists, asterisks, bold, markdown, headings, or placeholders.
Do not mention missing information. If something is missing, omit it cleanly.
Do not use any banned template language such as "I kindly request", "I urge you to", or "should be taken into account".
Do not pad with filler. Make the letter longer only by adding relevant substance: clear reasoning, evidence pressure, and correct legal or regulatory anchoring.

Case summary:
Customer: ${fullName}, email ${email}`;
  if (phone) caseContext += `, phone ${phone}`;
  if (address) caseContext += `, address ${address}`;
  if (postcode) caseContext += `, ${postcode}`;
  caseContext += `\nDate of letter: ${today}`;
  if (utilityProvider) caseContext += `\nProvider: ${utilityProvider}`;
  if (accountNumber) caseContext += `\nAccount number: ${accountNumber}`;
  if (billReference) caseContext += `\nBill reference: ${billReference}`;
  if (complaintType) caseContext += `\n\nComplaint type: ${complaintType}`;
  if (issueDate) caseContext += `\nIssue date: ${issueDate}`;
  if (amountDisputed) caseContext += `\nAmount disputed: ${amountDisputed}`;
  if (previousComplaint && previousComplaint.toLowerCase() !== 'no') caseContext += `\nPrevious complaint: ${previousComplaint}`;
  caseContext += `\n\nWhat happened:\n${whatHappened || 'Billing discrepancies'}`;
  if (additionalDetails) caseContext += `\n\nAdditional context:\n${additionalDetails}`;

  caseContext += `

Utility requirements:
Include one short regulatory anchor paragraph appropriate to the sector:
- energy: Ofgem or Energy Ombudsman route
- broadband or mobile: Ofcom or ADR route
- water: CCW support route
Do not invent timescales or escalation triggers if dates are missing.
Always request a written final response if unresolved.
A measured impact paragraph is allowed if the facts support it.

Write the final letter now.`;

  return caseContext;
}

function buildEmployerPrompt(data: any, fullName: string, email: string, today: string): string {
  const employerName = clean(data.employer_name);
  const jobTitle = clean(data.job_title);
  const managerName = clean(data.manager_name);
  const employmentStartDate = clean(data.employment_start_date);
  const issueType = clean(data.issue_type);
  const incidentDate = clean(data.incident_date);
  const whatHappened = clean(data.what_happened);
  const additionalDetails = clean(data.additional_details);
  const phone = clean(data.phone);
  const address = clean(data.address);
  const postcode = clean(data.postcode);

  let caseContext = `You are drafting a formal UK workplace grievance letter.

Premium Output Contract:
Write one complete, ready-to-send UK letter in natural paragraphs only.
The letter must contain at least 5 substantive body paragraphs, excluding addresses and sign-off.
It must feel strong, specific, and professionally drafted, not generic.
Do not use bullet points, numbered lists, asterisks, bold, markdown, headings, or placeholders.
Do not mention missing information. If something is missing, omit it cleanly.
Do not use any banned template language such as "I kindly request", "I urge you to", or "should be taken into account".
Do not pad with filler. Make the letter longer only by adding relevant substance: clear reasoning, evidence pressure, and correct legal or regulatory anchoring.

Mark as PRIVATE AND CONFIDENTIAL.

Case summary:
Employee: ${fullName}, email ${email}`;
  if (phone) caseContext += `, phone ${phone}`;
  if (address) caseContext += `, address ${address}`;
  if (postcode) caseContext += `, ${postcode}`;
  caseContext += `\nDate of letter: ${today}`;
  if (employerName) caseContext += `\nEmployer: ${employerName}`;
  if (jobTitle) caseContext += `\nJob title: ${jobTitle}`;
  if (managerName) caseContext += `\nManager/HR contact: ${managerName}`;
  if (employmentStartDate) caseContext += `\nEmployment start date: ${employmentStartDate}`;
  if (issueType) caseContext += `\n\nIssue type: ${issueType}`;
  if (incidentDate) caseContext += `\nIncident date: ${incidentDate}`;
  caseContext += `\n\nWhat happened:\n${whatHappened || 'Workplace concerns'}`;
  if (additionalDetails) caseContext += `\n\nAdditional context:\n${additionalDetails}`;

  caseContext += `

Employer requirements:
Include one short legal or procedural anchor paragraph referencing the ACAS Code of Practice and, only if relevant, Employment Rights Act 1996.
Keep the tone careful and factual.
Request a grievance meeting, investigation, and written outcome.
If the facts suggest time sensitivity, mention ACAS Early Conciliation cautiously and do not invent tribunal deadlines.
A measured impact paragraph is allowed only if the facts support it.

Write the final letter now.`;

  return caseContext;
}

function buildConsumerPrompt(data: any, fullName: string, email: string, today: string): string {
  const traderName = clean(data.trader_name);
  const orderReference = clean(data.order_reference);
  const purchaseDate = clean(data.purchase_date);
  const itemService = clean(data.item_service);
  const amountPaid = clean(data.amount_paid);
  const problemType = clean(data.problem_type);
  const whatHappened = clean(data.what_happened);
  const additionalDetails = clean(data.additional_details);
  const phone = clean(data.phone);
  const address = clean(data.address);
  const postcode = clean(data.postcode);

  let caseContext = `You are drafting a formal UK consumer rights complaint letter.

Premium Output Contract:
Write one complete, ready-to-send UK letter in natural paragraphs only.
The letter must contain at least 5 substantive body paragraphs, excluding addresses and sign-off.
It must feel strong, specific, and professionally drafted, not generic.
Do not use bullet points, numbered lists, asterisks, bold, markdown, headings, or placeholders.
Do not mention missing information. If something is missing, omit it cleanly.
Do not use any banned template language such as "I kindly request", "I urge you to", or "should be taken into account".
Do not pad with filler. Make the letter longer only by adding relevant substance: clear reasoning, evidence pressure, and correct legal or regulatory anchoring.

Case summary:
Consumer: ${fullName}, email ${email}`;
  if (phone) caseContext += `, phone ${phone}`;
  if (address) caseContext += `, address ${address}`;
  if (postcode) caseContext += `, ${postcode}`;
  caseContext += `\nDate of letter: ${today}`;
  if (traderName) caseContext += `\nBusiness: ${traderName}`;
  if (orderReference) caseContext += `\nOrder reference: ${orderReference}`;
  if (purchaseDate) caseContext += `\nPurchase date: ${purchaseDate}`;
  if (itemService) caseContext += `\nItem/Service: ${itemService}`;
  if (amountPaid) caseContext += `\nAmount paid: £${amountPaid}`;
  if (problemType) caseContext += `\n\nProblem type: ${problemType}`;
  caseContext += `\n\nWhat happened:\n${whatHappened || 'Consumer rights issue'}`;
  if (additionalDetails) caseContext += `\n\nAdditional context:\n${additionalDetails}`;

  caseContext += `

Refund and consumer requirements:
Include one short legal anchor paragraph referencing the Consumer Rights Act 2015 where relevant.
If the facts indicate distance selling cancellation, mention the Consumer Contracts regulations in one sentence only.
If payment method is card and the facts support it, include a calm one-sentence escalation signal that the matter may also be raised with the card provider where applicable.
Always demand a specific remedy and a clear next step if unresolved, but do not over-threaten.

Write the final letter now.`;

  return caseContext;
}
